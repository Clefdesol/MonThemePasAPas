<footer>

<p class="textFooter">Copyright © Clefdesol <?php echo date("Y"); ?></p>

    <!--  C'est le menu du footer que j'ai enlevé porovisoirement.
     <?php
    wp_nav_menu([
        'menu' => 'menu 2',
        'theme_location' => 'footer',
        'container' => 'footer ul',
        'container_class' => '',
        'container_id' => '',
        'menu_class' => '',
    ]);
    ?> -->
</footer>

<?php wp_footer(); ?>
</body>
</html>