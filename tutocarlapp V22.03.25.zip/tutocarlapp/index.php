<?php get_header(); ?>

<?php get_template_part('include','header'); ?>

<h1>Bienvenu chez Orion</h1>

<?php get_template_part('include','articleListe'); ?>





<?php get_footer(); ?>