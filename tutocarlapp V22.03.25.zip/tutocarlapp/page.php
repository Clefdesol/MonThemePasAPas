<?php get_header(); ?>

<?php get_template_part('include','header'); ?>



<article id="page">
    <div class="lerond">
    <h6><?php the_title(); ?></h6>

    </div>
   
    <section>
        <?php the_content(); ?>
    </section>

</article>

<div class="h15"></div>







<?php get_footer(); ?>

;