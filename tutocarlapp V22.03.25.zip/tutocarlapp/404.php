<?php get_header(); ?>

<?php get_template_part('include','header'); ?>

<article>
    <div class="imgarticle" style="background-image: url(<?= get_template_directory_uri(); ?>/assets/images/html-386093_1280.jpg);"></div>

    <h1>Erreur 404</h1>

    <section class="article">
        <p>La page demandée n'existe pas ou a été supprimée</p>


    </section>

</article>



<?php get_footer(); ?> 